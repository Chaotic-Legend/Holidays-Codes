#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    printf("HAPPY THANKSGIVING!!!\n");
    printf("From Isaac Hoyos!\n");
}