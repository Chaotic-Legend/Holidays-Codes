#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)


{
    printf("I wonder if spring is on the way,I'll go and check the weather today...\n");
    printf("Happy Groundhog Day!\n");
    printf("From Isaac Hoyos!\n");
}
    