#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)

{
    printf("“If freedom of speech is taken away, then dumb and silent we may be led, like sheep to the slaughter.” – George Washington\n");
    printf("“Pride costs us more than hunger, thirst and cold.” — Thomas Jefferson\n");
    printf("“When they call the roll in the Senate, the senators do not know whether to answer ‘present’ or ‘not guilty.’” — Theodore Roosevelt\n");
    printf("“If this is coffee, please bring me some tea; but if this is tea, please bring me some coffee.” — Abraham Lincoln\n");
    printf("Happy President Day!\n");
    printf("From Isaac Hoyos!\n");
}