#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)

{
    printf("Men and women always want to be a code's first love, but code like to be a man's and women's last romance.\n");
    printf("Happy Valentine's Day!\n");
    printf("Love Isaac Hoyos!\n");
}
