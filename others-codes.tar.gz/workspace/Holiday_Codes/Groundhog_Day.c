#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)


{
    printf("Old Groundhog stretched in his leafy bed. He turned over slowly and then he said, “I wonder if spring is on the way, I’ll go and check the weather today…”– Unknownn\n");
    printf("Happy Groundhog Day From Isaac Hoyos!\n");
}
    