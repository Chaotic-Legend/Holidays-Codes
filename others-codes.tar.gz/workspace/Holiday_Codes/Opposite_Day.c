#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)

{
    printf("¡ǝpoɔ ǝʇɐɥ I\n");
    printf("I love code!\n");
    printf("¡ʎɐp ǝʇᴉsoddo ʎddɐɥun\n");
    printf("Happy Opposite Day!\n");
    printf("¡soʎoH ɔɐɐsI ɯoɹℲ\n");
    printf("From Isaac Hoyos!\n");
}
