#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)

{
    printf("Every leap year I like to jump. It’s a good way to get my daily exercise in every four years. — Jarod Kintz\n");
    printf("Happy Leap Day From Isaac Hoyos\n");
}
    