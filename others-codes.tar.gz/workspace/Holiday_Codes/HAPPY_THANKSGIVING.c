#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    printf("“Thanksgiving dinners take 18 hours to prepare. They are consumed in 12 minutes. Halftimes take 12 minutes. This is not coincidence.” -- Erma Bombeck\n");
    printf("Happy Thanksgiving From Isaac Hoyos!\n");
}