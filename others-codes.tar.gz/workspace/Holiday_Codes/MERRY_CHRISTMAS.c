#include <stdio.h>
#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)

{ 
       int MERRY_CHRISTMAS;
       MERRY_CHRISTMAS = 0;
    
       while (MERRY_CHRISTMAS<3) 
       {
    
            printf("WE WISH YOU A MERRY CHRISTMAS!!!\n");
            MERRY_CHRISTMAS = MERRY_CHRISTMAS+1;
       }
    printf("AND HAPPY NEW YEAR!!!\n");
    printf("From Isaac Hoyos!\n");
    
}