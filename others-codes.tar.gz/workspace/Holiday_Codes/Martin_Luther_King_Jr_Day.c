#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

int main(void)


{
    printf("I Have Dream!...\n");
    printf("We honor You Martin Luther King Jr!\n");
    printf("From Isaac Hoyos!\n");
}