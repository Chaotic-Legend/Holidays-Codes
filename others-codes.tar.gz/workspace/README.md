# Other_Codes
This is for others kinds of codes
